/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xspips.h"

#define SPI_DEVICE_1_ID     XPAR_XSPIPS_1_DEVICE_ID

#define SPI_SELECT  0x0

/*
 * The following constant specify the max amount of data the slave is
 * expecting to receive from the master.
 */
#define MAX_DATA        100

/**************************** Type Definitions *******************************/

/***************** Macros (Inline Functions) Definitions *********************/

#define SpiPs_RecvByte(BaseAddress) \
        (u8)XSpiPs_In32((BaseAddress) + XSPIPS_RXD_OFFSET)

#define SpiPs_SendByte(BaseAddress, Data) \
        XSpiPs_Out32((BaseAddress) + XSPIPS_TXD_OFFSET, (Data))

/************************** Function Prototypes ******************************/

void SpiSlaveRead(int ByteCount);

void SpiSlaveWrite(u8 *Sendbuffer, int ByteCount);

/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs. They could be local
 * but should at least be static so they are zeroed.
 */

static XSpiPs SpiInstance_1;

/*
 * The ReadBuffer is used to read to the data which it received from the SPI
 * Bus which master has sent.
 */

u8 SentBuffer[MAX_DATA];


int main()
{
    init_platform();

    xil_printf("Cao2.");

        memset(SentBuffer, 0x00, sizeof(SentBuffer));
        SentBuffer[0]=0xa;
        SentBuffer[1]=0xb;
        SentBuffer[2]=0xc;
        SentBuffer[3]=0xd;


        int Status_1;
        u8 *BufferPtr;
        XSpiPs_Config *SpiConfig_1;

        /*
         * Initialize the SPI driver so that it's ready to use
         */
        SpiConfig_1 = XSpiPs_LookupConfig(SPI_DEVICE_1_ID);
        if (NULL == SpiConfig_1) {
            return XST_FAILURE;
        }

        Status_1 = XSpiPs_CfgInitialize((&SpiInstance_1), SpiConfig_1,
                        SpiConfig_1->BaseAddress);
        if (Status_1 != XST_SUCCESS) {
            return XST_FAILURE;
        }
        xil_printf("XSpiPs_CfgInitialize\r\n");

        XSpiPs_SetOptions(&SpiInstance_1, XSPIPS_MASTER_OPTION |
                       XSPIPS_FORCE_SSELECT_OPTION);

            XSpiPs_SetClkPrescaler(&SpiInstance_1, XSPIPS_CLK_PRESCALE_64);
            xil_printf("XSpiPs_SetClkPrescaler\r\n");

            /*
             * Assert the EEPROM chip select
             */
            XSpiPs_SetSlaveSelect(&SpiInstance_1, SPI_SELECT);
            xil_printf("XSpiPs_SetSlaveSelect\r\n");

            /*
             * Set the Rx FIFO Threshold to the Max Data
             */
            //XSpiPs_SetRXWatermark((&SpiInstance_1),MAX_DATA);

            /*
             * Enable the device.
             */
            XSpiPs_Enable((&SpiInstance_1));

            xil_printf("Ja sam master.");

            /*
             * Read the contents of the Receive buffer
             * Master is expected to send MAX_DATA number of bytes
             */

            BufferPtr=SentBuffer;

            SpiSlaveWrite(BufferPtr, MAX_DATA);
            xil_printf("poslao");

            while(1){

            }

            XSpiPs_Disable((&SpiInstance_1));

            xil_printf("kraj");

    cleanup_platform();
    return 0;
}




/*****************************************************************************/
/**
*
* This function writes Data into the Tx buffer
*
* @param    Sendbuffer is the buffer whose data is to be sent onto the
*       Tx FIFO.
* @param    ByteCount is the number of bytes to be read from Rx buffer.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
void SpiSlaveWrite(u8 *Sendbuffer, int ByteCount)
{
    u32 StatusReg;
    int TransCount = 0;

    StatusReg = XSpiPs_ReadReg(SpiInstance_1.Config.BaseAddress,
                XSPIPS_SR_OFFSET);

    /*
     * Fill the TXFIFO with as many bytes as it will take (or as
     * many as we have to send).
     */
    while ((ByteCount > 0) &&
        (TransCount < XSPIPS_FIFO_DEPTH)) {
        SpiPs_SendByte(SpiInstance_1.Config.BaseAddress,
                *Sendbuffer);
        Sendbuffer++;
        ++TransCount;
        ByteCount--;
    }

    xil_printf("\r\n spremio buffer");

    /*
     * Wait for the transfer to finish by polling Tx fifo status.
     */
    do {
        StatusReg = XSpiPs_ReadReg(
                SpiInstance_1.Config.BaseAddress,
                    XSPIPS_SR_OFFSET);
    } while ((StatusReg & XSPIPS_IXR_TXOW_MASK) == 0);

}

